import { getSupabase } from './supabase.js';
import { PRICE_RULES } from './config.js';

const DEMO_PLAYERS = [
  {id:'demo-rin',name:'Rin Itoshi',team_name:'PXG',position:'ST',number:10,bio:'Demo oyuncu kaydı. Supabase bağlandığında gerçek veriler kullanılır.',goals:12,assists:6,match_ups:8,critical_interventions:3},
  {id:'demo-isagi',name:'Yoichi Isagi',team_name:'Bastard München',position:'ST',number:11,bio:'Demo oyuncu kaydı.',goals:10,assists:9,match_ups:11,critical_interventions:2},
  {id:'demo-sae',name:'Sae Itoshi',team_name:'U-20',position:'MF',number:8,bio:'Demo oyuncu kaydı.',goals:7,assists:12,match_ups:5,critical_interventions:4},
  {id:'demo-aiku',name:'Oliver Aiku',team_name:'Ubers',position:'CB',number:2,bio:'Demo oyuncu kaydı.',goals:2,assists:2,match_ups:14,critical_interventions:10},
  {id:'demo-shidou',name:'Ryusei Shidou',team_name:'PXG',position:'ST',number:9,bio:'Demo oyuncu kaydı.',goals:13,assists:3,match_ups:9,critical_interventions:1},
  {id:'demo-reo',name:'Reo Mikage',team_name:'Manshine City',position:'MF',number:7,bio:'Demo oyuncu kaydı.',goals:5,assists:8,match_ups:7,critical_interventions:6}
];

function decorate(p){
  return {...p, market_value:
    (p.goals||0)*PRICE_RULES.goal+
    (p.assists||0)*PRICE_RULES.assist+
    (p.match_ups||0)*PRICE_RULES.match_up+
    (p.critical_interventions||0)*PRICE_RULES.critical_intervention
  };
}
export function money(v){ return new Intl.NumberFormat('tr-TR').format(v||0)+' ₺'; }

export async function getPlayers(){
  const sb = await getSupabase();
  if(!sb) return DEMO_PLAYERS.map(decorate);
  const {data,error} = await sb.from('player_stats').select('*').order('name');
  if(error) { console.error(error); return DEMO_PLAYERS.map(decorate); }
  return (data||[]).map(decorate);
}
export async function getPlayer(id){
  const ps=await getPlayers(); return ps.find(p=>String(p.id)===String(id));
}
export async function getMatches(){
  const sb=await getSupabase();
  if(!sb) return [
    {id:'m1',home_team_name:'PXG',away_team_name:'Bastard München',home_score:3,away_score:2,status:'FULL TIME',played_at:new Date().toISOString()},
    {id:'m2',home_team_name:'Ubers',away_team_name:'Manshine City',home_score:1,away_score:1,status:'FULL TIME',played_at:new Date(Date.now()-86400000*2).toISOString()}
  ];
  const {data,error}=await sb.from('matches_with_teams').select('*').order('played_at',{ascending:false});
  if(error){console.error(error);return []} return data||[];
}
export async function addPlayer(payload){
  const sb=await getSupabase(); if(!sb)return {data:null,error:new Error('Supabase bağlantısı yapılmamış. js/config.js dosyasını doldur.')};
  return await sb.from('players').insert(payload).select().single();
}
export async function addTeam(payload){
  const sb=await getSupabase(); if(!sb)return {data:null,error:new Error('Supabase bağlantısı yapılmamış. js/config.js dosyasını doldur.')};
  return await sb.from('teams').insert(payload).select().single();
}
